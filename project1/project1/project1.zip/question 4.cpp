/*#define _CRT_SECURE_NO_WARNINGS 
#include <stdio.h>

void main(void){
int leng, wid, height, vol;
printf("Please enter the length, width, then height of the box to calculate the volume\n");
scanf("%d %d %d", &leng, &wid, &height);
vol = leng * wid * height;
printf("The volume of the box is %d\n", vol);
}*/