/*#define _CRT_SECURE_NO_WARNINGS 
#include <stdio.h>

void main (void){
int n1, n2, n3;
printf("Please enter three numbers\n");
scanf("%d %d %d", &n1, &n2, &n3);
printf("Your numbers forward:\n%d\n%d\n%d\nYour numbers reversed are:\n%d\n%d\n%d\nYour numbers in a line seperated by commas:\n%d,%d,%d,\n", n1, n2, n3, n3, n2, n1, n1, n2, n3);	
}*/