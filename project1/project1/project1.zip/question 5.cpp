/*#define _CRT_SECURE_NO_WARNINGS 
#include <stdio.h>

void main(void){
float x, y, s, p, total;
printf("Enter your x value then your y value\n");
scanf("%f %f", &x, &y);
p = x * y;
s = x + y;
total = s*s + p * (s - x) * (p + y);
printf("The value of p is %.2f\n The value of s is %.2f\n The total is %.2f\n", p, s, total);
}*/