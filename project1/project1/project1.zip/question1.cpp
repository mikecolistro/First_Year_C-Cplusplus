/*#include <stdio.h>

void main (void){
	char c;
	int y;
	float z;
	printf("Enter a Integer than a Character than a Float\n ***Seperate your entrees by a single space***\n ");
	scanf("%d %c %f", &y, &c, &z);
	printf("The Characer is %c\nThe Integer is %d\nThe Float is %.2f\n", c, y, z);
	
}*/